const sdk = require('node-appwrite');

module.exports = async ({ req, res, log, error }) => {
  // Get calling user's ID from Appwrite-injected header
  const userId = req.headers['x-appwrite-user-id'];
  if (!userId) {
    return res.json({ success: false, error: 'Not authenticated' }, 401);
  }

  // Parse body
  let body;
  try {
    body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  } catch (e) {
    return res.json({ success: false, error: 'Invalid request body' }, 400);
  }

  const teamId = body?.teamId;
  if (!teamId || typeof teamId !== 'string') {
    return res.json({ success: false, error: 'Missing teamId' }, 400);
  }

  log(`join-house: userId=${userId} teamId=${teamId}`);

  // Build admin client using API key
  const client = new sdk.Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const teams = new sdk.Teams(client);
  const users = new sdk.Users(client);

  // Check if already a member (also verifies the team exists)
  try {
    const existing = await teams.listMemberships(teamId, [sdk.Query.equal('userId', userId)]);
    if (existing.total > 0) {
      return res.json({ success: false, error: 'Already a member of this house' }, 400);
    }
  } catch (e) {
    log(`listMemberships error: ${e.message}`);
    return res.json({ success: false, error: 'Invalid invite code — house not found' }, 404);
  }

  // Get user info to create membership
  let userRecord;
  try {
    userRecord = await users.get(userId);
  } catch (e) {
    log(`users.get error: ${e.message}`);
    return res.json({ success: false, error: 'Could not retrieve user info' }, 500);
  }

  // Create membership (auto-accepted since we use the userId param)
  try {
    await teams.createMembership(
      teamId,
      [],                              // roles (empty — house owner assigns roles)
      userRecord.email,
      userId,
      undefined,                       // phone
      'homy://accept-invite',          // redirect URL (unused for server-side accept)
      userRecord.name || ''
    );
    log(`join-house: success, ${userRecord.email} joined team ${teamId}`);
    return res.json({ success: true });
  } catch (e) {
    log(`createMembership error: ${e.message}`);
    return res.json({ success: false, error: e.message }, 500);
  }
};
